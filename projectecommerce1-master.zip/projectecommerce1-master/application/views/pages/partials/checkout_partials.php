        <aside>
            <div class="sidewidt">
              <h2 class="heading2"><span> TAHAPAN CHECKOUT</span></h2>
              <ul class="nav nav-list categories">
                <li>
                  <a href="<?=base_url('checkout')?>">CHECKOUT</a>
                </li>
                <li>
                  <a href="<?=base_url('checkout/detail_pengiriman')?>">DETAIL PENGIRIMAN</a>
                </li>
                <li>
                  <a href="<?=base_url('checkout/detail_pesanan')?>">DETAIL PEMESANAN</a>
                </li>
                <li>
                  <a href="<?=base_url('checkout/selesai')?>">SELESAI</a>
                </li>
              </ul>
            </div>
          </aside>