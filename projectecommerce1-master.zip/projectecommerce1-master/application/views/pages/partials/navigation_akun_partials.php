        <div class="sidewidt">
            <h2 class="heading2"><span>NAVIGASI MEMBER</span></h2>
            <ul class="nav nav-list categories">
              <li>
                <a href="<?=base_url('/detail_akun.html')?>">BERANDA</a>
              </li>
              <li>
                <a href="<?=base_url('/daftar_pemesanan.html')?>">DAFTAR PEMESANAN</a>
              </li>
              <li>
                <a href="<?=base_url('/ubah_akun.html')?>">UBAH PROFIL</a>
              </li>
              <li>
                <a href="<?=base_url('/ubah_password.html')?>">UBAH PASSWORD</a>
              </li>
              <li>
                <a href="<?=base_url('/logout.html')?>">LOGOUT</a>
              </li>
            </ul>
          </div>