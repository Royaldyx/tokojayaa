        <div class="row">
			<ol class="breadcrumb">
				<li><a href="<?=base_url('/administrator.html')?>"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Dashboard</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">
                    <i class="fa fa-dashboard"></i>
                    Welcome <?=$this->session->userdata('administrator')['nama']?>!!! | Repost by <a href='https://stokcoding.com/' title='StokCoding.com' target='_blank'>StokCoding.com</a>
					
                </h1>
			</div>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-md-12">
				<p>Aplikasi Penjualan (Website E-Commerce) ini merupakan Tugas Kerja Praktek (KP). <br />
					Tugas ini dikerjakan oleh MISWANTO (1303040041). <br />
					UNIVERSITAS MUHAMMDIYAH PURWOKERTO (UMP)</p>
			</div>
		</div><!--/.row-->